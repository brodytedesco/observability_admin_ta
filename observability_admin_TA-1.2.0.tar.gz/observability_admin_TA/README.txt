This TA is made to bring Splunk Observability data about the platform itself into Splunk Core.
It's built with the UCC Framework

# Binary File Declaration
lib/charset_normalizer/md.cpython-310-x86_64-linux-gnu.so: this file does not require any source code, included with ucc-gen
lib/charset_normalizer/md__mypyc.cpython-310-x86_64-linux-gnu.so: this file does not require any source code, included with ucc-gen